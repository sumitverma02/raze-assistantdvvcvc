const mineflayer = require('mineflayer')

function createBot() {
  const bot = mineflayer.createBot({
    host: 'YOUR_SERVER_IP.powerupstack.host', // Yahan apne PowerupStack server ka IP dalein
    port: YOUR_PORT,                        // Yahan Port number dalein (jaise 25565)
    version: '1.20.4',                      // Server ka version (ya false chhod sakte hain auto-detect ke liye)
    username: 'AFK_Guardian'                // Bot ka naam jo server me dikhega
  })

  bot.on('spawn', () => {
    console.log('Bot successfully server me enter ho gaya hai!')

    // Har 1 minute me ek baar halka sa sir ghumayega (No movement, Only Look)
    setInterval(() => {
      const yaw = Math.random() * Math.PI * 2
      const pitch = (Math.random() * Math.PI) - (Math.PI / 2)
      bot.look(yaw, pitch, true)
    }, 60000) // 60000ms = 1 minute
  })

  bot.on('kicked', (reason) => {
    console.log(`Bot kick ho gaya: ${reason}`)
    attemptReconnect()
  })

  bot.on('error', (err) => {
    console.log('Error aaya:', err)
  })

  bot.on('end', () => {
    console.log('Connection toot gaya, reconnect kar rahe hain...')
    attemptReconnect()
  })
}

function attemptReconnect() {
  setTimeout(() => {
    console.log('Dubara connect hone ki koshish...')
    createBot()
  }, 10000) // 10 seconds ke baad dobara try karega
}

createBot()